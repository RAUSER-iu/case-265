import React from "https://esm.sh/react";
import ReactDOM from "https://esm.sh/react-dom";
import Case265Page from "./app.js";

ReactDOM.render(React.createElement(Case265Page), document.getElementById("root"));
